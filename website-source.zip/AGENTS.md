# Maintainer handoff
Read README.md. This is the public static deployment of the independent website. Preserve existing visual design and academic credentials. Do not change the original CV without user-provided evidence. Use Node.js 24, npm ci, npm run typecheck, npm run build. Never add private data or credentials. Public output is out/. No backend is deployed.
