# Kaiyuan Shi — public static website

Public profile extracted from independent website v1.0.0. Original design, academic text and CV are preserved. Private workspace, authentication and database routes are excluded from this deployment copy; the original archive is unchanged.

## Development
Node.js 24. Run `npm ci`, `npm run dev`. Production: `npm run typecheck` and `npm run build`. Static output is in `out/`.

## GitHub Pages
Create public repository `programming-sunshine.github.io` in account `Programming-sunshine`. Upload this project to `main`. Set Settings → Pages → Source to GitHub Actions. The included workflow builds and deploys it. Expected URL after successful deployment: https://programming-sunshine.github.io/ . No custom domain is configured.

This repository contains public website content and the original public CV only. Never add credentials or private files. Standard Next.js source can be maintained by any developer or AI.
