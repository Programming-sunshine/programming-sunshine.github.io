import { notFound } from "next/navigation";
const titles: Record<string, [string, string]> = {
  about: [
    "About",
    "A foundation in engineering. A curiosity for what comes next.",
  ],
  research: [
    "Research",
    "Material behavior, experimental evidence and data-driven construction.",
  ],
  publications: [
    "Publications & innovation",
    "Research outputs and ideas under development.",
  ],
  experience: [
    "Experience & recognition",
    "Learning through research, competition and international exchange.",
  ],
  contact: [
    "Contact",
    "For research conversations, academic exchange and engineering opportunities.",
  ],
};
function Row({
  label,
  title,
  children,
  id,
}: {
  label: string;
  title: string;
  children: React.ReactNode;
  id?: string;
}) {
  return (
    <section id={id} className="content-row">
      <aside>{label}</aside>
      <article>
        <h2>{title}</h2>
        {children}
      </article>
    </section>
  );
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  return { title: titles[section]?.[0] || "Page" };
}
export default async function Page({
  params,
}: {
  params: Promise<{ section: string }>;
}) {
  const { section } = await params;
  if (!titles[section]) notFound();
  return (
    <main id="main" className="wrap">
      <div className="page-head">
        <p className="eyebrow">KAIYUAN SHI / {section.toUpperCase()}</p>
        <h1>{titles[section][0]}</h1>
        <p className="prose">{titles[section][1]}</p>
      </div>
      <div className="page-body">
        {section === "about" && (
          <>
            <Row label="PROFILE" title="Kaiyuan Shi">
              <p>
                I study Engineering Cost at Henan University of Engineering,
                with an expected graduation in 2028. My academic interests sit
                at the intersection of civil materials, experimental mechanics
                and intelligent construction.
              </p>
              <p>
                I am interested in how engineering decisions can be supported by
                a better understanding of material behavior and reliable
                predictive models. In the longer term, I hope to combine
                graduate research with international engineering cost practice.
              </p>
            </Row>
            <Row label="EDUCATION" title="Henan University of Engineering">
              <p>
                Undergraduate studies · Engineering Cost
                <br />
                Expected graduation: 2028 · Henan, China
              </p>
              <p>
                Academic training includes surveying, engineering mechanics,
                construction materials, concrete structures, building
                construction and engineering drawing.
              </p>
            </Row>
            <Row
              label="RESEARCH INTERESTS"
              title="Questions that connect data and materials"
            >
              <div className="tags">
                {[
                  "AI-based prediction",
                  "3D-printed concrete",
                  "Fresh-state deformation",
                  "Intelligent construction",
                  "Modified soils",
                  "Self-healing materials",
                ].map((x) => (
                  <span className="tag" key={x}>
                    {x}
                  </span>
                ))}
              </div>
            </Row>
            <Row
              label="SKILLS & PRACTICE"
              title="An evolving engineering toolkit"
            >
              <div className="details-grid">
                <div>
                  <h3>Engineering</h3>
                  <p>
                    CAD · Glodon construction cost software · engineering
                    drawings
                  </p>
                </div>
                <div>
                  <h3>Research & laboratory</h3>
                  <p>
                    Triaxial testing · concrete 3D printing · experimental data
                    analysis
                  </p>
                </div>
                <div>
                  <h3>Digital tools</h3>
                  <p>Origin · Microsoft Office · Python coursework</p>
                </div>
                <div>
                  <h3>Languages</h3>
                  <p>
                    Chinese · English
                    <br />
                    CET-6: 496
                  </p>
                </div>
              </div>
            </Row>
            <Row label="BEYOND RESEARCH" title="Service and personal interests">
              <p>
                Academic affairs representative for my class and an assistant in
                the university’s international affairs office. Outside
                engineering, I enjoy calligraphy and spending time outdoors.
              </p>
            </Row>
          </>
        )}
        {section === "research" && (
          <>
            <Row
              id="concrete"
              label="01 / DIGITAL CONSTRUCTION"
              title="AI-based prediction for 3D-printed concrete"
            >
              <p>
                Predicting settlement and deformation is an important part of
                understanding how freshly printed concrete behaves. This
                research area connects data-driven modeling with the material
                and process conditions of additive construction.
              </p>
              <h3>Research focus</h3>
              <p>
                Settlement and deformation prediction, fresh-state behavior and
                the use of AI methods in concrete 3D printing.
              </p>
              <p className="notice">
                The exact model, dataset and individual contribution will be
                added from the verified manuscript. This is a topic summary, not
                the paper’s formal title.
              </p>
              <a
                className="text-link"
                href="https://doi.org/10.1080/10589759.2026.2633451"
                target="_blank"
                rel="noreferrer"
              >
                Publication DOI ↗
              </a>
              <div className="tags">
                <span className="tag">Machine learning</span>
                <span className="tag">3D-printed concrete</span>
                <span className="tag">Deformation</span>
              </div>
            </Row>
            <Row
              id="loess"
              label="02 / JUN 2025 – JUN 2026"
              title="Nano-SiO₂ modified loess"
            >
              <p>
                Research team member studying the mechanical and time-dependent
                behavior of loess modified with nano-silica.
              </p>
              <h3>Methods and contribution</h3>
              <p>
                Participated in a program involving 32 triaxial specimens and
                analysis using a four-element Burgers model.
              </p>
              <h3>Reported project results</h3>
              <p>
                Model fits reached R² = 0.990–0.994; the reported reduction in
                void ratio was 7.94%. These are project-level results.
              </p>
              <div className="tags">
                <span className="tag">Triaxial testing</span>
                <span className="tag">Burgers model</span>
                <span className="tag">Soil improvement</span>
              </div>
            </Row>
            <Row
              id="healing"
              label="03 / JAN 2025 – PRESENT"
              title="Self-healing stabilized road-base materials"
            >
              <p>
                Core team member working on crush-resistant microcapsules for
                stabilized road-base materials. The project investigates
                microcapsules that can withstand compaction and contribute to
                material repair.
              </p>
              <h3>Methods and contribution</h3>
              <p>
                Contributed to shell-material formulations and crush-resistance
                design, with triaxial, permeability and durability testing. Took
                a principal drafting role in patent materials.
              </p>
              <h3>Innovation output</h3>
              <p>
                An invention patent application has been published. Application
                status is listed separately from granted patents.
              </p>
              <a className="text-link" href="/publications#patents">
                View patent record ↗
              </a>
            </Row>
          </>
        )}
        {section === "publications" && (
          <>
            <p className="notice">
              Bibliographic details are being completed. Topic labels below are
              not substitutes for exact publication titles; author order and
              journal metadata have not yet been verified.
            </p>
            <Row
              label="2026 / ENGLISH JOURNAL ARTICLE"
              title="3D-printed concrete settlement prediction"
            >
              <p>
                Research topic: AI-based prediction of settlement or deformation
                in 3D-printed concrete.
              </p>
              <p>
                Exact title, author list, journal, volume and article number:{" "}
                <strong>to be confirmed from the publication.</strong>
              </p>
              <a
                className="text-link"
                target="_blank"
                rel="noreferrer"
                href="https://doi.org/10.1080/10589759.2026.2633451"
              >
                DOI: 10.1080/10589759.2026.2633451 ↗
              </a>
            </Row>
            <Row
              label="2026 / CHINESE JOURNAL ARTICLE"
              title="Chinese-language publication"
            >
              <p>
                Pages 75–77. Exact title, author list and journal:{" "}
                <strong>to be confirmed from the publication.</strong>
              </p>
              <a
                className="text-link"
                target="_blank"
                rel="noreferrer"
                href="https://doi.org/10.20087/j.cnki.1672-8114.2026.03.024"
              >
                DOI: 10.20087/j.cnki.1672-8114.2026.03.024 ↗
              </a>
            </Row>
            <Row
              id="patents"
              label="PATENT / PUBLISHED APPLICATION"
              title="Crush-resistant microcapsule self-healing road-base material"
            >
              <p>
                Chinese invention patent application · Publication number{" "}
                <strong>CN121609556A</strong>.
              </p>
              <p>
                English wording is a descriptive translation. Exact title,
                inventor order and current examination status are awaiting
                verification against the official record. This is not presented
                as a granted patent.
              </p>
            </Row>
          </>
        )}
        {section === "experience" && (
          <>
            <Row label="AUG 2026 / GENEVA" title="AFS Youth Assembly">
              <p>
                <strong>
                  Selected Delegate · “豫见世界” overseas study program
                </strong>
              </p>
              <p>
                Selected through university and provincial assessment for the
                Henan overseas study program. The provincial interview involved
                52 candidates from 27 universities; the final delegation
                included 30 students from 20 universities.
              </p>
              <p>
                Participated in international exchanges in Geneva around rights,
                education, climate adaptation and dialogue, including a visit to
                the World Health Organization.
              </p>
              <div className="tags">
                <span className="tag">International exchange</span>
                <span className="tag">Youth dialogue</span>
                <span className="tag">AFS Global Competence Certificate</span>
              </div>
            </Row>
            <Row
              label="SELECTED RECOGNITION"
              title="Competitions & scholarships"
            >
              <div className="timeline">
                <article>
                  <span>NATIONAL</span>
                  <h3>Challenge Cup · Third Prize</h3>
                  <p>
                    National collegiate innovation and entrepreneurship
                    competition.
                  </p>
                </article>
                <article>
                  <span>2025 / HENAN</span>
                  <h3>
                    China International College Students’ Innovation Competition
                  </h3>
                  <p>Provincial First Prize.</p>
                </article>
                <article>
                  <span>HENAN / 17TH EDITION</span>
                  <h3>Challenge Cup · Special Prize</h3>
                  <p>Provincial award.</p>
                </article>
                <article>
                  <span>SCHOLARSHIP</span>
                  <h3>National Encouragement Scholarship</h3>
                  <p>国家励志奖学金</p>
                </article>
              </div>
            </Row>
            <Row
              label="CREDENTIALS"
              title="Certificates & supporting documents"
            >
              <div className="details-grid">
                <div className="detail-card">
                  <h3>AFS Global Competence Certificate</h3>
                  <p>International learning and intercultural engagement.</p>
                  <p className="certificate-note">
                    Certificate image not yet added.
                  </p>
                </div>
                <div className="detail-card">
                  <h3>College English Test, Band 6</h3>
                  <p>Score: 496</p>
                  <p className="certificate-note">
                    Score report not yet added.
                  </p>
                </div>
              </div>
            </Row>
          </>
        )}
        {section === "contact" && (
          <>
            <Row label="EMAIL" title="Let’s get in touch.">
              <a className="contact-email" href="mailto:kai@shikaiyuan.com">
                kai@shikaiyuan.com ↗
              </a>
              <p style={{ marginTop: 20 }}>
                I welcome conversations about civil materials, 3D-printed
                concrete, research opportunities and international engineering.
              </p>
            </Row>
            <Row label="ACADEMIC & PROFESSIONAL" title="Elsewhere">
              <div className="credentials">
                {["LinkedIn", "ORCID", "Google Scholar", "GitHub"].map((x) => (
                  <span key={x} className="social-placeholder">
                    {x} · link to be added
                  </span>
                ))}
              </div>
            </Row>
            <Row label="BACKGROUND" title="A concise introduction">
              <p>
                For education, research experience and selected recognition,
                view the current CV.
              </p>
              <a className="primary-link" href="/cv">
                View CV ↗
              </a>
            </Row>
          </>
        )}
      </div>
    </main>
  );
}

export function generateStaticParams() { return Object.keys(titles).map(section => ({ section })); }
