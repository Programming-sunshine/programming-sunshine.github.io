export const metadata = { title: "CV" };
export default function CV() {
  return (
    <main id="main" className="wrap page-body">
      <div className="page-head">
        <p className="eyebrow">KAIYUAN SHI / CURRICULUM VITAE</p>
        <h1>Curriculum vitae.</h1>
        <p className="prose">
          Education, research experience and selected achievements.
        </p>
        <div className="actions">
          <a
            className="primary-link"
            href="/documents/Kaiyuan-Shi-CV.pdf"
            target="_blank"
            rel="noreferrer"
          >
            Open original PDF ↗
          </a>
          <a
            className="text-link"
            href="/documents/Kaiyuan-Shi-CV.pdf"
            download="Kaiyuan-Shi-CV.pdf"
          >
            Download CV ↓
          </a>
        </div>
        <p className="muted" style={{ marginTop: 20 }}>
          Original one-page CV · Select the preview to open the PDF and zoom in.
        </p>
      </div>
      <a
        href="/documents/Kaiyuan-Shi-CV.pdf"
        target="_blank"
        rel="noreferrer"
        className="original-cv"
        aria-label="Open Kaiyuan Shi’s original CV PDF"
      >
        <img
          src="/documents/Kaiyuan-Shi-CV-preview.png"
          width="1275"
          height="1800"
          alt="Kaiyuan Shi’s original one-page CV, including education, research experience, publications, patents, scholarships, awards and skills."
        />
      </a>
    </main>
  );
}
