import type { Metadata } from "next";
import "./globals.css";
import Nav from "./site-nav";
export const metadata: Metadata = {
  title: {
    default: "Kaiyuan Shi — Engineering & Research",
    template: "%s | Kaiyuan Shi",
  },
  description:
    "Engineering cost, civil materials and data-driven construction. The personal website of Kaiyuan Shi.",
  icons: { icon: "/favicon.svg" },
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <a className="skip-link" href="#main">
          Skip to content
        </a>
        <Nav />
        {children}
        <footer className="wrap site-footer">
          <div>
            <strong>Kaiyuan Shi</strong>
            <p>Engineering, research & a wider perspective.</p>
          </div>
          <div>
            <a href="mailto:kai@shikaiyuan.com">kai@shikaiyuan.com ↗</a>
            <p>© {new Date().getFullYear()} Kaiyuan Shi</p>
          </div>
        </footer>
      </body>
    </html>
  );
}
