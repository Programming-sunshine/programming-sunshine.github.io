export default function Home() {
  return (
    <main id="main">
      <section className="hero wrap">
        <div>
          <p className="eyebrow">KAIYUAN SHI / PERSONAL WEBSITE</p>
          <h1>
            Engineering.
            <br />
            Research.
            <br />
            <em>A wider perspective.</em>
          </h1>
          <p className="hero-copy">
            I’m Kaiyuan Shi, an undergraduate in Engineering Cost at Henan
            University of Engineering. I explore how data and materials can help
            us build better.
          </p>
          <div className="actions">
            <a className="primary-link" href="/research">
              Explore my research <span>↗</span>
            </a>
            <a className="text-link" href="/cv">
              View CV ↗
            </a>
          </div>
        </div>
        <aside className="identity">
          <div className="monogram" aria-label="Kaiyuan Shi monogram">
            KS<span>凯元</span>
          </div>
          <div className="identity-bottom">
            <p>Kaiyuan Shi</p>
            <span>
              Engineering Cost · Civil Engineering
              <br />
              Henan, China
            </span>
          </div>
        </aside>
      </section>
      <div className="topic-band">
        <div className="wrap">
          RESEARCH INTERESTS <span>AI & data-driven modeling</span>
          <span>3D-printed concrete</span>
          <span>Advanced civil materials</span>
        </div>
      </div>
      <section className="wrap section">
        <div className="section-top">
          <div>
            <p className="eyebrow">01 / SELECTED WORK</p>
            <h2>
              From material behavior
              <br />
              to intelligent construction.
            </h2>
          </div>
          <a className="text-link" href="/research">
            All research ↗
          </a>
        </div>
        <div className="research-grid">
          <a className="research-card featured" href="/research#concrete">
            <span className="eyebrow">01 · DIGITAL CONSTRUCTION</span>
            <h3>
              Understanding how
              <br />
              printed concrete settles.
            </h3>
            <p>
              AI-based settlement and deformation prediction for 3D-printed
              concrete.
            </p>
            <span className="card-bottom">
              Research focus <b>↗</b>
            </span>
          </a>
          <a className="research-card" href="/research#loess">
            <span className="eyebrow">02 · GEOTECHNICAL MATERIALS</span>
            <h3>
              Nano-SiO₂
              <br />
              modified loess.
            </h3>
            <p>
              Experimental characterization and time-dependent mechanical
              behavior.
            </p>
            <span className="card-bottom">
              2025–2026 <b>↗</b>
            </span>
          </a>
          <a className="research-card" href="/research#healing">
            <span className="eyebrow">03 · MATERIAL INNOVATION</span>
            <h3>
              Materials that
              <br />
              repair from within.
            </h3>
            <p>
              Crush-resistant microcapsules for self-healing stabilized
              road-base materials.
            </p>
            <span className="card-bottom">
              Ongoing work <b>↗</b>
            </span>
          </a>
        </div>
      </section>
      <section className="wrap section split-section">
        <div>
          <p className="eyebrow">02 / BEYOND THE LAB</p>
          <h2>
            A local foundation.
            <br />
            An international outlook.
          </h2>
          <p className="prose">
            Engineering connects people, places and ideas. My experience as a
            selected delegate in Geneva strengthened my interest in working
            across disciplines and borders.
          </p>
          <a href="/experience" className="text-link">
            Experience & recognition ↗
          </a>
        </div>
        <div className="timeline">
          <article>
            <span>2026 / GENEVA</span>
            <h3>AFS Youth Assembly</h3>
            <p>Selected delegate · “豫见世界” overseas study program</p>
          </article>
          <article>
            <span>RESEARCH & INNOVATION</span>
            <h3>Challenge Cup</h3>
            <p>National Third Prize · provincial recognition</p>
          </article>
          <article>
            <span>LOOKING AHEAD</span>
            <h3>International engineering</h3>
            <p>
              Graduate research and engineering cost practice across borders.
            </p>
          </article>
        </div>
      </section>
    </main>
  );
}
