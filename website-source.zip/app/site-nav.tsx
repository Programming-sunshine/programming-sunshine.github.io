const links = [
  ["/", "Home"],
  ["/about", "About"],
  ["/research", "Research"],
  ["/publications", "Publications"],
  ["/experience", "Experience"],
  ["/cv", "CV"],
  ["/contact", "Contact"],
];
function Links() {
  return (
    <>
      {links.map(([href, label]) => (
        <a key={href} href={href}>
          {label}
        </a>
      ))}
    </>
  );
}
export default function Nav() {
  return (
    <header className="site-header">
      <div className="wrap nav-inner">
        <a className="brand" href="/">
          <span>KS</span>Kaiyuan Shi
        </a>
        <nav className="nav-links desktop-nav" aria-label="Main navigation">
          <Links />
        </nav>
        <details className="mobile-navigation">
          <summary>
            Menu <span aria-hidden="true">☰</span>
          </summary>
          <nav className="mobile-links" aria-label="Mobile navigation">
            <Links />
          </nav>
        </details>
      </div>
    </header>
  );
}
